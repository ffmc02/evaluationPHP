<?php
$title='detail de l\'album';
$detail=new discModel();
$modelDetailList=$detail->readDisc();
if(isset($_GET['id'])){
    $dicId= htmlspecialchars($_GET['id']);
}