<?php

$title = 'formulaire d\'ajout de vinyle';
//on vas chercher les données de la table artist et de la colonne name artiste grace a la methode readArtist
$listeArtiste = new artist();
$listerArtistes = $listeArtiste->readArtist();
// on vas chercher la méthode d'ajout de disc grace a la methode addDisc
$addDisc = new discModel();
$addDiscsUseur = $addDisc->addDisc();
//défintion des regex
$regexTitle = '/^[a-zÃƒÂ©ÃƒÂ¨ÃƒÂªÃƒÂ«ÃƒÂ ÃƒÂ¢ÃƒÂ®ÃƒÂ¯ÃƒÂ´ÃƒÂ¶ÃƒÂ»ÃƒÂ¼-]+$/';
$regexYears = '/^(\d{4})$/';
$regexPrice= '/^(\d{1,6})[.,](\d{0,2})$/';
$regexId = '/^\d+$/';
// initialisation d'un tableau d'erreur
$formError = array();
//recupération des données du formulaire
if (isset($_POST['submit'])) {
    if (!empty($_POST['title'])) {
        if (preg_match($regexTitle, $_POST['title'])) {
            //on mes les donné du champs title dans la variable qui appel la classe discModel et la méthode addDisc
            $addDiscsUseur->disc_title = htmlspecialchars($_POST['title']);
        } else {
            //erreur ne rentre pas dans la regex 
        }
    } else {
        //erreur champs vide title OK 
    }
    if (!empty($_POST['artist'])) {
        if (preg_match($regexId, $_POST['artist'])) {
            $addDiscsUseur->artist_id= htmlspecialchars($_POST['artist']);
        } else {
            //erreur ne rentre pas dans la regex ID OK         
        }
    } else {
//        erreur champs vide
    }
    if (!empty($_POST['year'])) {
        if (preg_match($regexYears, $_POST['year'])) {
            if ($_POST['year'] >= 1950 && $_POST['year'] <= 2020) {
                $addDiscsUseur->disc_year = htmlspecialchars($_POST['year']);
            } else {
                //erreur dans les dates (non compris entre 1960 et 2020 OK
            }
        } else {
            //erruer dans la regex
        }
    } else {
        //errreur de champs vide
    }
    if (!empty($_POST['Genre'])) {
        if (preg_match($regexTitle, $_POST['Genre'])) {
            $addDiscsUseur->disc_genre = htmlspecialchars($_POST['Genre']);
        } else {
            //erreur ne rentre pas dans la regex
        }
    } else {
        //erreur si vide    
    }
    if(!empty($_POST['Label'])){
        if(preg_match($regexTitle, $_POST['Label'])){
            $addDiscsUseur->disc_label= htmlspecialchars($_POST['Label']);
        } else {
        // erreur  regex    
        }
    } else {
    //erreur champs vide    
    }
    if(!empty($_['Price'])){
        if(preg_match($regexTitle, $_POST['Price'])){
            $addDiscsUseur->disc_price= htmlspecialchars($_POST['Price']);
        } else {
        //erreur de regex
            
        }
    }
    else {
    //erreur champs vide  
        
    }
//    var_dump($_POST);

    var_dump($addDiscsUseur);
}
