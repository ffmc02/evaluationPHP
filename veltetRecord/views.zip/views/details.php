<?php
include_once '../config.php';
include_once '../controllers/detailCtrl.php';
include_once  'includ/header.php';
include_once 'includ/navbar.php';
?>
<main>
     <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12 text-center">
                        <h1>Detail du discque </h1>
                    </div>
                    <div class="col-sm-12 text-center">
                        <?php 
                        
                        foreach ($modelDetailList as $modelDetailListe){
                            $iddisc= $modelDetailListe->disc_id ;
                            if($iddisc==$dicId){
                            ?>
                        
                        <!--<p> <?= $modelDetailListe->disc_id ?></p>-->
                        <p>Titre : <?= $modelDetailListe->disc_title ?></p>
                        <p><img src="../assets/img/<?= $modelDetailListe->disc_picture ?>" </p>
                        <p>Année : <?= $modelDetailListe->disc_year ?></p>
                        <p>Label : <?= $modelDetailListe->disc_label ?></p>
                        <p>Genre : <?= $modelDetailListe->disc_genre ?></p>
                        <p>Prix : <?= $modelDetailListe->disc_price ?></p>
                        <p>Artiste : <?= $modelDetailListe->artist_name ?></p>
                      <?php
                        }}
                        ?>
                    </div>
                </div>
         </div>
</main>
<?php
include 'includ/footer.php';
?>
