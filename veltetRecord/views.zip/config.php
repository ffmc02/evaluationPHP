<?php
include_once 'model/dataBase.php';
include_once 'model/discModel.php';
include_once 'model/artistModel.php';